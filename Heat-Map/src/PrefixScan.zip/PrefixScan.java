/***
 * @file GeneralScan.java
 * @author John Nguyen
 * CPSC 5600 HW5A
 * 
 * Generic Reduce and Scan Class using Java's ForkJoinPool 
 * 
 */

import java.util.ArrayList;
import java.util.List;



public class PrefixScan extends GeneralScan<Integer, TallyDoubAdd> {
	
	public PrefixScan(List<Integer> raw) {
		//default threshold of 100
		super(raw, 100);
	}
	
	
	public PrefixScan(List<Integer> raw, int threshold) {
		super(raw, threshold);
	}
	
	@Override
	protected TallyDoubAdd init() {
		return new TallyDoubAdd(0.0);
	}
	
	@Override
	protected TallyDoubAdd prepare(Integer datum) {
		return new TallyDoubAdd(datum);
	}
	
	@Override
	protected TallyDoubAdd combine(TallyDoubAdd left, TallyDoubAdd right) {
		//System.out.println(left.d + " " + right.d);
		return new TallyDoubAdd(left.d + right.d);
	}
	
	
	//accum should take two lists and append the records together within the left list
	@Override
	protected void accum(TallyDoubAdd left, TallyDoubAdd right) {
		left.accum(right.d);
	}
	
	@Override
	protected TallyDoubAdd cloneTally(TallyDoubAdd tally) {
		return tally.clone();
	}
	
	
	public static void main(String[] args) {
		// Create test array of data from -1 to 1
		int n = 1<<20;
		
		//generate test data
		List<Integer> testData = new ArrayList<Integer>(n);
		for(int i = 1; i <= n; i++) {
			testData.add(i);
		}
		
		PrefixScan pScan = new PrefixScan(testData, 4);
		
		//Compute and print out sum		
		System.out.println("Reduction: " + pScan.getReduction(0).d);
		
		//create arraylist for storing scan result
		ArrayList<TallyDoubAdd> output = new ArrayList<TallyDoubAdd>(n);
		
		//initialize output array
		while(output.size()<n)
			output.add(new TallyDoubAdd(0.0));


		//call the scan function
		pScan.getScan(output);
		
		//print out the scan of the prefix sums
		for(int i=0; i< 10; i++)
			System.out.println("i: " + i +", value: " + output.get(i).d);
		System.out.println("i: " + (n-1) +", value: " + output.get(n-1).d);
		
	}

}
